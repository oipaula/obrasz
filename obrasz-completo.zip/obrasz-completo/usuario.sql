create database obrasz_phpt2;
use obrasz_phpt2;
create table usuario (
nome varchar(40),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;